# Работа с Cisco Packet Tracer

Ниже можно по порядку увидеть скриншоты как я делала, с настройками, пингом, сайтом и в конце пакет.
Оно не идеально, но я старалась. И сам .pkt файл с сетью тоже загрузила.

![Packet Tracer 01](Packet_tracer_01.jpg)
![Packet Tracer 02](Packet_tracer_02.jpg)
![Packet Tracer 03](Packet_tracer_03.jpg)
![Packet Tracer 04](Packet_tracer_04.jpg)
![Packet Tracer 05](Packet_tracer_05.jpg)
![Packet Tracer 06](Packet_tracer_06.jpg)
![Packet Tracer 07](Packet_tracer_07.jpg)
![Packet Tracer 08](Packet_tracer_08.jpg)
![Packet Tracer 09](Packet_tracer_09.jpg)
![Packet Tracer 10](Packet_tracer_10.jpg)
![Packet Tracer 11](Packet_tracer_11.jpg)
![Packet Tracer 12](Packet_tracer_12.jpg)
![Packet Tracer 13](Packet_tracer_13.jpg)
![Packet Tracer 14](Packet_tracer_14.jpg)

