# Домашнее задание 7

## 1. SQL
На тренажере SQLBolt я прошла 8 уровней. Cкриншот прогресса:  

![SQL Level 8](SQL_8.jpg)

## 2. Лабораторные работы по OWASP TOP 10

### 2.1 Лабораторные работы по Broken Access Control
- **Lab Broken Access Control 1:**
![Laba 1](Laba_1.jpg)  
  
- **Lab Broken Access Control 2:**
![Laba 2](Laba_2.jpg)

### 2.2 Лабораторная работа по Injection
- **Lab Injection 1:**
![Laba 3 - SQL Injection](Laba_3_SQL.jpg)  

### 2.3 Лабораторная работа по Server-Side Request Forgery (SSRF)
- **Lab SSRF 1:**
![Laba 4 - SSRF](Laba_4_SSRF.jpg)
  
## 3. Тренировка поиска уязвимостей на примере OWASP Juice Shop  
Сделала некоторые штуки, больше всего понравилось про Бендера)
![OWASP Juice Shop Result](./OWASP_Juice_Shop.jpg)
