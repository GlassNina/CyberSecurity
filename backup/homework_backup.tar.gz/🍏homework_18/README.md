## Домашнее задание № 18   
### Защита инфраструктуры приложений  
#### Часть 2 : honeypot, sandbox, DAC, MFA  

#### 1. Установить 2FA на linux (Google authenticator)  
#### Прислать скрин о запросе кода авторизации  

![Скриншот 1](Homework_18_01.jpg)  
![Скриншот 2](Homework_18_02.jpg)  
![Скриншот 3](Homework_18_03.jpg)  
![Скриншот 4](Homework_18_04.jpg)  
![Скриншот 5](Homework_18_05.jpg)  
![Скриншот 6](Homework_18_06.jpg)  
![Скриншот 7](Homework_18_07.jpg)  

#### 2. any.run  
#### Регистрируемся, тестим ссылки и файлы в sandbox  
![Скриншот 8](Homework_18_08.jpg)  
![Скриншот 9](Homework_18_09.jpg)  
![Скриншот 10](Homework_18_10.jpg)  
